# Earthquake Disaster Management System

A Streamlit-based application for earthquake disaster management with agentic AI capabilities. This system provides real-time visualization, analysis, and AI-powered insights for earthquake events worldwide.

## Features

1. **Global Earthquake Visualization**
   - Interactive world map showing earthquake events
   - Color-coded by magnitude and impact
   - Filtering by magnitude, depth, and time

2. **Detailed Analysis**
   - Fault line visualization
   - Impact zone mapping
   - Infrastructure damage assessment
   - Capacity analysis for critical facilities

3. **AI-Powered Insights**
   - Risk assessment for specific locations
   - Impact simulation with detailed predictions
   - Emergency response plan generation
   - Preparedness recommendations

4. **Agentic AI Capabilities**
   - Sophisticated machine learning models for seismic event simulation
   - Integration of multi-source data (geological sensors, urban layout, population density)
   - Real-time prediction and scenario simulation
   - Actionable insights for vulnerable areas
   - Scalable and adaptable to different urban contexts

## Installation

1. Clone this repository
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Create a `.env` file with your TogetherAI API key:
   ```
   TOGETHER_API_KEY=your_api_key_here
   ```

## Usage

Run the Streamlit application:

```
streamlit run app.py
```

The application will be available at http://localhost:8501

## Components

- **app.py**: Main Streamlit application
- **data_generator.py**: Generates dummy earthquake and infrastructure data
- **ai_agent.py**: Handles interactions with TogetherAI API for intelligent analysis

## Data Sources

Currently using dummy data for demonstration purposes. In a production environment, this would be connected to:

- USGS Earthquake Data API
- National Geophysical Data Center
- Local infrastructure and population databases
- Real-time seismic monitoring networks

## AI Model

The application uses TogetherAI's Llama-3.3-70B-Instruct-Turbo-Free model for generating insights, simulations, and recommendations.

## Future Enhancements

- Integration with real-time earthquake data sources
- Machine learning models for improved prediction accuracy
- Mobile alerts and notifications
- Community response coordination features
- Historical data analysis and pattern recognition

## License

MIT