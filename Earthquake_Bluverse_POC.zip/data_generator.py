import pandas as pd
import numpy as np
import geopandas as gpd
from datetime import datetime, timedelta
import random

def generate_global_earthquake_data(num_events=100):
    """
    Generate dummy global earthquake data for visualization
    """
    # Random coordinates around the world, with focus on seismic zones
    # Pacific Ring of Fire, Mediterranean-Himalayan belt, etc.
    seismic_zones = [
        # Pacific Ring of Fire
        {'lat_range': (30, 45), 'lon_range': (130, 145), 'weight': 0.2},  # Japan
        {'lat_range': (-10, 10), 'lon_range': (120, 135), 'weight': 0.15},  # Indonesia
        {'lat_range': (35, 42), 'lon_range': (-125, -115), 'weight': 0.1},  # US West Coast
        {'lat_range': (-40, -30), 'lon_range': (-75, -65), 'weight': 0.1},  # Chile
        
        # Mediterranean-Himalayan belt
        {'lat_range': (35, 45), 'lon_range': (20, 45), 'weight': 0.15},  # Turkey, Iran
        {'lat_range': (25, 35), 'lon_range': (65, 80), 'weight': 0.1},  # Northern India
        
        # Other regions
        {'lat_range': (-50, 50), 'lon_range': (-180, 180), 'weight': 0.2},  # Rest of world
    ]
    
    # Generate random events based on weighted zones
    lats = []
    lons = []
    for _ in range(num_events):
        zone = random.choices(seismic_zones, weights=[z['weight'] for z in seismic_zones], k=1)[0]
        lat = random.uniform(zone['lat_range'][0], zone['lat_range'][1])
        lon = random.uniform(zone['lon_range'][0], zone['lon_range'][1])
        lats.append(lat)
        lons.append(lon)
    
    # Generate random magnitudes with realistic distribution
    # Most earthquakes are small, fewer are large
    magnitudes = np.random.exponential(scale=1.0, size=num_events) + 4.0
    magnitudes = np.clip(magnitudes, 4.0, 9.0)
    
    # Generate random depths with realistic distribution
    depths = np.random.exponential(scale=30, size=num_events)
    depths = np.clip(depths, 5, 300)
    
    # Generate timestamps within the last 30 days
    end_date = datetime.now()
    start_date = end_date - timedelta(days=30)
    timestamps = [start_date + timedelta(
        days=random.uniform(0, 30),
        hours=random.uniform(0, 24),
        minutes=random.uniform(0, 60)
    ) for _ in range(num_events)]
    
    # Create DataFrame
    df = pd.DataFrame({
        'latitude': lats,
        'longitude': lons,
        'magnitude': magnitudes,
        'depth_km': depths,
        'timestamp': timestamps,
        'impact_radius_km': magnitudes * 10,  # Simple model for impact radius
    })
    
    # Add some calculated fields for visualization
    df['color'] = pd.cut(
        df['magnitude'],
        bins=[0, 5.0, 6.0, 7.0, 10.0],
        labels=['green', 'yellow', 'orange', 'red']
    )
    
    return df

def generate_detailed_earthquake_data(lat, lon, magnitude, num_points=500):
    """
    Generate detailed earthquake data for a specific location
    including fault lines and impact zones
    """
    # Create a central point for the earthquake
    center_lat, center_lon = lat, lon
    
    # Generate fault line (simplified as a line with some randomness)
    # Direction of fault is random but consistent
    fault_direction = random.uniform(0, 2 * np.pi)
    fault_length = magnitude * 15  # km
    
    # Convert to degrees (approximate)
    km_per_degree_lat = 111  # Approximate km per degree of latitude
    km_per_degree_lon = 111 * np.cos(np.radians(center_lat))  # Varies with latitude
    
    fault_delta_lat = fault_length * np.sin(fault_direction) / km_per_degree_lat
    fault_delta_lon = fault_length * np.cos(fault_direction) / km_per_degree_lon
    
    # Generate points along the fault line with some randomness
    num_fault_points = 50
    t_values = np.linspace(-0.5, 0.5, num_fault_points)
    
    fault_lats = center_lat + fault_delta_lat * t_values
    fault_lons = center_lon + fault_delta_lon * t_values
    
    # Add some randomness to the fault line
    fault_lats += np.random.normal(0, 0.02, num_fault_points)
    fault_lons += np.random.normal(0, 0.02, num_fault_points)
    
    fault_df = pd.DataFrame({
        'latitude': fault_lats,
        'longitude': fault_lons,
        'type': 'fault_line'
    })
    
    # Generate impact zones (concentric circles with decreasing intensity)
    impact_zones = []
    num_circles = 4
    max_radius_km = magnitude * 10
    
    for i in range(num_circles):
        radius_km = max_radius_km * (i + 1) / num_circles
        points_in_circle = int(num_points / num_circles)
        
        # Generate points in a circle
        thetas = np.linspace(0, 2 * np.pi, points_in_circle)
        
        # Convert radius from km to degrees (approximate)
        radius_lat = radius_km / km_per_degree_lat
        radius_lon = radius_km / km_per_degree_lon
        
        circle_lats = center_lat + radius_lat * np.sin(thetas)
        circle_lons = center_lon + radius_lon * np.cos(thetas)
        
        # Add some randomness
        jitter = 0.1 * radius_km / km_per_degree_lat
        circle_lats += np.random.normal(0, jitter, points_in_circle)
        circle_lons += np.random.normal(0, jitter, points_in_circle)
        
        # Assign color based on intensity (distance from center)
        if i == 0:
            color = 'red'
        elif i == 1:
            color = 'orange'
        elif i == 2:
            color = 'yellow'
        else:
            color = 'green'
        
        for j in range(points_in_circle):
            impact_zones.append({
                'latitude': circle_lats[j],
                'longitude': circle_lons[j],
                'intensity': 1 - (i / num_circles),
                'color': color,
                'type': 'impact_zone'
            })
    
    impact_df = pd.DataFrame(impact_zones)
    
    # Combine fault lines and impact zones
    combined_df = pd.concat([fault_df, impact_df], ignore_index=True)
    
    return combined_df

def generate_infrastructure_data(region_lat, region_lon, radius_km=50, num_points=100):
    """
    Generate dummy infrastructure data for a specific region
    """
    # Convert radius from km to degrees (approximate)
    km_per_degree_lat = 111  # Approximate km per degree of latitude
    km_per_degree_lon = 111 * np.cos(np.radians(region_lat))  # Varies with latitude
    
    radius_lat = radius_km / km_per_degree_lat
    radius_lon = radius_km / km_per_degree_lon
    
    # Infrastructure types
    infra_types = [
        {'type': 'hospital', 'weight': 0.1, 'icon': 'hospital'},
        {'type': 'school', 'weight': 0.2, 'icon': 'school'},
        {'type': 'fire_station', 'weight': 0.05, 'icon': 'fire-station'},
        {'type': 'police_station', 'weight': 0.05, 'icon': 'police'},
        {'type': 'shelter', 'weight': 0.1, 'icon': 'shelter'},
        {'type': 'power_plant', 'weight': 0.02, 'icon': 'power'},
        {'type': 'water_treatment', 'weight': 0.03, 'icon': 'water'},
        {'type': 'residential_building', 'weight': 0.45, 'icon': 'home'}
    ]
    
    # Generate random points within the radius
    infrastructure = []
    
    for _ in range(num_points):
        # Random angle and distance from center
        angle = random.uniform(0, 2 * np.pi)
        distance_factor = random.uniform(0, 1) ** 0.5  # Square root for more uniform distribution
        
        # Calculate position
        lat = region_lat + radius_lat * distance_factor * np.sin(angle)
        lon = region_lon + radius_lon * distance_factor * np.cos(angle)
        
        # Select infrastructure type
        infra = random.choices(infra_types, weights=[i['weight'] for i in infra_types], k=1)[0]
        
        # Generate capacity based on type
        if infra['type'] in ['hospital', 'shelter']:
            capacity = random.randint(50, 500)
        elif infra['type'] in ['school']:
            capacity = random.randint(200, 1000)
        elif infra['type'] in ['residential_building']:
            capacity = random.randint(10, 200)
        else:
            capacity = random.randint(5, 50)
        
        infrastructure.append({
            'latitude': lat,
            'longitude': lon,
            'type': infra['type'],
            'icon': infra['icon'],
            'capacity': capacity,
            'damage_level': 0  # Will be calculated based on earthquake impact
        })
    
    return pd.DataFrame(infrastructure)

def calculate_infrastructure_impact(earthquake_data, infrastructure_data):
    """
    Calculate the impact of an earthquake on infrastructure
    """
    # Extract earthquake parameters
    eq_lat = earthquake_data['latitude']
    eq_lon = earthquake_data['longitude']
    magnitude = earthquake_data['magnitude']
    
    # Calculate distance from earthquake to each infrastructure point
    for idx, infra in infrastructure_data.iterrows():
        # Haversine formula for distance calculation
        lat1, lon1 = np.radians(eq_lat), np.radians(eq_lon)
        lat2, lon2 = np.radians(infra['latitude']), np.radians(infra['longitude'])
        
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
        c = 2 * np.arcsin(np.sqrt(a))
        distance_km = 6371 * c  # Earth radius in km
        
        # Calculate damage based on distance and magnitude
        # Simple model: damage decreases with distance and increases with magnitude
        max_impact_radius = magnitude * 10  # km
        if distance_km <= max_impact_radius:
            # Damage level from 0 to 1
            damage = (1 - (distance_km / max_impact_radius)) * (magnitude / 10)
            # Add some randomness
            damage = min(1.0, max(0.0, damage + random.uniform(-0.1, 0.1)))
            infrastructure_data.at[idx, 'damage_level'] = damage
    
    return infrastructure_data