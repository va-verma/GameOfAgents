import streamlit as st
import pandas as pd
import numpy as np
import folium
from streamlit_folium import folium_static
import plotly.express as px
import plotly.graph_objects as go
import matplotlib.pyplot as plt
import json
from datetime import datetime, timedelta

# Import our custom modules
from data_generator import (
    generate_global_earthquake_data,
    generate_detailed_earthquake_data,
    generate_infrastructure_data,
    calculate_infrastructure_impact
)
from ai_agent import EarthquakeAIAgent

# Page configuration
st.set_page_config(page_title="Earthquake Disaster Management System", layout="wide")

# Initialize session state
if 'earthquake_data' not in st.session_state:
    st.session_state.earthquake_data = generate_global_earthquake_data(num_events=150)

if 'selected_earthquake' not in st.session_state:
    st.session_state.selected_earthquake = None

if 'detailed_data' not in st.session_state:
    st.session_state.detailed_data = None

if 'infrastructure_data' not in st.session_state:
    st.session_state.infrastructure_data = None

if 'ai_agent' not in st.session_state:
    try:
        st.session_state.ai_agent = EarthquakeAIAgent()
    except ValueError as e:
        st.error(f"Error initializing AI Agent: {e}")
        st.session_state.ai_agent = None

# Helper functions
def create_global_map(data):
    """
    Create a folium map with global earthquake data
    """
    # Create a map centered at the mean of the data points
    m = folium.Map(location=[20, 0], zoom_start=2, tiles="CartoDB positron")
    
    # Add earthquake points
    for _, row in data.iterrows():
        # Scale the radius by magnitude
        radius = row['magnitude'] ** 2 / 2
        
        # Create popup content
        popup_content = f"""
        <b>Magnitude:</b> {row['magnitude']:.1f}<br>
        <b>Depth:</b> {row['depth_km']:.1f} km<br>
        <b>Time:</b> {row['timestamp'].strftime('%Y-%m-%d %H:%M')}<br>
        <b>Impact Radius:</b> {row['impact_radius_km']:.1f} km<br>
        <button onclick="selectEarthquake({row['latitude']}, {row['longitude']}, {row['magnitude']}, {row['depth_km']})">View Details</button>
        """
        
        folium.CircleMarker(
            location=[row['latitude'], row['longitude']],
            radius=radius,
            color=row['color'],
            fill=True,
            fill_opacity=0.7,
            popup=folium.Popup(popup_content, max_width=300)
        ).add_to(m)
    
    # Add JavaScript for handling earthquake selection
    js = """
    <script>
    function selectEarthquake(lat, lon, mag, depth) {
        // Send data to Streamlit
        const data = {
            lat: lat,
            lon: lon,
            magnitude: mag,
            depth: depth
        };
        // Use window.parent.postMessage to communicate with Streamlit
        window.parent.postMessage({type: 'streamlit:selectEarthquake', data: data}, '*');
    }
    </script>
    """
    m.get_root().html.add_child(folium.Element(js))
    
    return m

def create_detailed_map(earthquake_data, detailed_data, infrastructure_data=None):
    """
    Create a detailed map for a specific earthquake location
    """
    # Extract earthquake location
    lat = earthquake_data['latitude']
    lon = earthquake_data['longitude']
    magnitude = earthquake_data['magnitude']
    
    # Create a map centered at the earthquake location
    m = folium.Map(location=[lat, lon], zoom_start=10, tiles="CartoDB positron")
    
    # Add earthquake epicenter
    folium.CircleMarker(
        location=[lat, lon],
        radius=10,
        color='red',
        fill=True,
        fill_opacity=1.0,
        popup=f"Epicenter: M{magnitude:.1f}"
    ).add_to(m)
    
    # Add fault lines
    fault_data = detailed_data[detailed_data['type'] == 'fault_line']
    fault_points = list(zip(fault_data['latitude'], fault_data['longitude']))
    folium.PolyLine(
        fault_points,
        color='red',
        weight=3,
        opacity=0.8,
        popup="Fault Line"
    ).add_to(m)
    
    # Add impact zones
    impact_data = detailed_data[detailed_data['type'] == 'impact_zone']
    for color in ['red', 'orange', 'yellow', 'green']:
        color_data = impact_data[impact_data['color'] == color]
        for _, row in color_data.iterrows():
            folium.CircleMarker(
                location=[row['latitude'], row['longitude']],
                radius=2,
                color=color,
                fill=True,
                fill_opacity=0.5,
                popup=f"Impact Zone: {row['intensity']:.2f}"
            ).add_to(m)
    
    # Add infrastructure if available
    if infrastructure_data is not None:
        for _, row in infrastructure_data.iterrows():
            # Determine icon and color based on type and damage
            icon_name = "home"
            if row['type'] == 'hospital':
                icon_name = "plus"
            elif row['type'] == 'school':
                icon_name = "school"
            elif row['type'] == 'shelter':
                icon_name = "home"
            elif row['type'] == 'fire_station':
                icon_name = "fire-extinguisher"
            elif row['type'] == 'police_station':
                icon_name = "shield"
            
            # Color based on damage level
            if row['damage_level'] > 0.7:
                color = 'red'
            elif row['damage_level'] > 0.4:
                color = 'orange'
            elif row['damage_level'] > 0.1:
                color = 'yellow'
            else:
                color = 'green'
            
            folium.Marker(
                location=[row['latitude'], row['longitude']],
                icon=folium.Icon(icon=icon_name, prefix='fa', color=color),
                popup=f"{row['type'].replace('_', ' ').title()}<br>Capacity: {row['capacity']}<br>Damage Level: {row['damage_level']:.2f}"
            ).add_to(m)
    
    return m

# Main application
st.title("Earthquake Disaster Management System")

# Sidebar for controls
st.sidebar.title("Controls")

# Option to regenerate data
if st.sidebar.button("Regenerate Earthquake Data"):
    st.session_state.earthquake_data = generate_global_earthquake_data(num_events=150)
    st.session_state.selected_earthquake = None
    st.session_state.detailed_data = None
    st.session_state.infrastructure_data = None

# Filter controls
st.sidebar.subheader("Filter Earthquakes")
min_magnitude = st.sidebar.slider("Minimum Magnitude", 4.0, 9.0, 4.0, 0.1)
max_depth = st.sidebar.slider("Maximum Depth (km)", 5.0, 300.0, 300.0, 5.0)
days_ago = st.sidebar.slider("Days Ago", 1, 30, 30)

# Apply filters
filtered_data = st.session_state.earthquake_data[
    (st.session_state.earthquake_data['magnitude'] >= min_magnitude) &
    (st.session_state.earthquake_data['depth_km'] <= max_depth) &
    (st.session_state.earthquake_data['timestamp'] >= datetime.now() - timedelta(days=days_ago))
]

# Main content area with tabs
tab1, tab2, tab3 = st.tabs(["Global View", "Detailed Analysis", "AI Insights"])

with tab1:
    st.header("Global Earthquake Activity")
    
    # Display statistics
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Earthquakes", len(filtered_data))
    with col2:
        st.metric("Avg. Magnitude", f"{filtered_data['magnitude'].mean():.1f}")
    with col3:
        st.metric("Max Magnitude", f"{filtered_data['magnitude'].max():.1f}")
    with col4:
        st.metric("Avg. Depth", f"{filtered_data['depth_km'].mean():.1f} km")
    
    # Display the map
    st.subheader("Earthquake Map")
    global_map = create_global_map(filtered_data)
    folium_static(global_map, width=1200, height=600)
    
    # Display data table
    st.subheader("Earthquake Data")
    display_data = filtered_data.copy()
    display_data['timestamp'] = display_data['timestamp'].dt.strftime('%Y-%m-%d %H:%M')
    display_data = display_data[['latitude', 'longitude', 'magnitude', 'depth_km', 'timestamp']]
    st.dataframe(display_data, use_container_width=True)
    
    # Allow manual selection of earthquake for detailed view
    st.subheader("Select Earthquake for Detailed Analysis")
    selected_idx = st.selectbox(
        "Select an earthquake to analyze:",
        options=range(len(filtered_data)),
        format_func=lambda i: f"M{filtered_data.iloc[i]['magnitude']:.1f} at {filtered_data.iloc[i]['latitude']:.2f}, {filtered_data.iloc[i]['longitude']:.2f} on {filtered_data.iloc[i]['timestamp'].strftime('%Y-%m-%d')}"
    )
    
    if st.button("Analyze Selected Earthquake"):
        st.session_state.selected_earthquake = filtered_data.iloc[selected_idx].to_dict()
        st.session_state.detailed_data = generate_detailed_earthquake_data(
            st.session_state.selected_earthquake['latitude'],
            st.session_state.selected_earthquake['longitude'],
            st.session_state.selected_earthquake['magnitude']
        )
        st.session_state.infrastructure_data = generate_infrastructure_data(
            st.session_state.selected_earthquake['latitude'],
            st.session_state.selected_earthquake['longitude'],
            radius_km=st.session_state.selected_earthquake['magnitude'] * 10
        )
        st.session_state.infrastructure_data = calculate_infrastructure_impact(
            st.session_state.selected_earthquake,
            st.session_state.infrastructure_data
        )
        st.rerun()

with tab2:
    if st.session_state.selected_earthquake is None:
        st.info("Please select an earthquake from the Global View tab for detailed analysis.")
    else:
        eq = st.session_state.selected_earthquake
        st.header(f"Detailed Analysis: M{eq['magnitude']:.1f} Earthquake")
        st.subheader(f"Location: {eq['latitude']:.4f}, {eq['longitude']:.4f} | Depth: {eq['depth_km']:.1f} km")
        
        # Display the detailed map
        detailed_map = create_detailed_map(
            st.session_state.selected_earthquake,
            st.session_state.detailed_data,
            st.session_state.infrastructure_data
        )
        folium_static(detailed_map, width=1200, height=600)
        
        # Infrastructure impact analysis
        st.subheader("Infrastructure Impact Analysis")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Damage distribution by infrastructure type
            infra_data = st.session_state.infrastructure_data
            damage_by_type = infra_data.groupby('type')['damage_level'].mean().reset_index()
            damage_by_type = damage_by_type.sort_values('damage_level', ascending=False)
            
            fig = px.bar(
                damage_by_type,
                x='type',
                y='damage_level',
                title="Average Damage by Infrastructure Type",
                labels={'type': 'Infrastructure Type', 'damage_level': 'Average Damage Level'},
                color='damage_level',
                color_continuous_scale='RdYlGn_r'
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Damage level distribution
            damage_bins = pd.cut(infra_data['damage_level'], bins=[0, 0.2, 0.4, 0.6, 0.8, 1.0], labels=['0-20%', '20-40%', '40-60%', '60-80%', '80-100%'])
            damage_counts = damage_bins.value_counts().sort_index()
            
            fig = px.pie(
                values=damage_counts.values,
                names=damage_counts.index,
                title="Infrastructure Damage Distribution",
                color_discrete_sequence=px.colors.sequential.RdBu_r
            )
            st.plotly_chart(fig, use_container_width=True)
        
        # Infrastructure capacity analysis
        st.subheader("Infrastructure Capacity Analysis")
        
        # Filter for critical infrastructure
        critical_infra = infra_data[infra_data['type'].isin(['hospital', 'shelter', 'fire_station', 'police_station'])]
        
        # Calculate available capacity based on damage level
        critical_infra['available_capacity'] = critical_infra['capacity'] * (1 - critical_infra['damage_level'])
        
        # Group by type and sum capacities
        capacity_by_type = critical_infra.groupby('type').agg({
            'capacity': 'sum',
            'available_capacity': 'sum'
        }).reset_index()
        
        # Create a grouped bar chart
        fig = go.Figure()
        
        fig.add_trace(go.Bar(
            x=capacity_by_type['type'],
            y=capacity_by_type['capacity'],
            name='Total Capacity',
            marker_color='blue'
        ))
        
        fig.add_trace(go.Bar(
            x=capacity_by_type['type'],
            y=capacity_by_type['available_capacity'],
            name='Available Capacity',
            marker_color='green'
        ))
        
        fig.update_layout(
            title="Critical Infrastructure Capacity Analysis",
            xaxis_title="Infrastructure Type",
            yaxis_title="Capacity",
            barmode='group'
        )
        
        st.plotly_chart(fig, use_container_width=True)

with tab3:
    if st.session_state.ai_agent is None:
        st.error("AI Agent could not be initialized. Please check your API key.")
    elif st.session_state.selected_earthquake is None:
        st.info("Please select an earthquake from the Global View tab for AI analysis.")
    else:
        st.header("AI-Powered Insights and Recommendations")
        
        # Get location name (this would normally come from geocoding, but we'll use coordinates for demo)
        eq = st.session_state.selected_earthquake
        location = f"Latitude {eq['latitude']:.4f}, Longitude {eq['longitude']:.4f}"
        
        # Tabs for different AI analyses
        ai_tab1, ai_tab2, ai_tab3 = st.tabs(["Risk Assessment", "Impact Simulation", "Response Plan"])
        
        with ai_tab1:
            st.subheader("Earthquake Risk Assessment")
            
            with st.spinner("Generating risk assessment with AI..."):
                # In a real app, we would cache this to avoid repeated API calls
                if 'risk_assessment' not in st.session_state:
                    try:
                        st.session_state.risk_assessment = st.session_state.ai_agent.analyze_earthquake_risk(location)
                    except Exception as e:
                        st.error(f"Error generating risk assessment: {e}")
                        st.session_state.risk_assessment = {"error": str(e)}

            ra = st.session_state.risk_assessment
            if 'error' in ra:
                st.error(ra['error'])
            elif 'raw_analysis' in ra:
                st.markdown(ra['raw_analysis'])
            elif 'choices' in ra:
                # If the API response is not parsed, show raw content
                st.markdown(str(ra['choices']))
            else:
                # Display structured risk assessment (Blueverse Foundry/GPT-4o mini)
                # Section names may differ, so show all keys
                for section, value in ra.items():
                    st.markdown(f"### {section.replace('_', ' ').title()}")
                    if isinstance(value, list):
                        for item in value:
                            st.markdown(f"- {item}")
                    else:
                        st.markdown(str(value))
        
        with ai_tab2:
            st.subheader("Earthquake Impact Simulation")
            
            with st.spinner("Simulating earthquake impact with AI..."):
                # In a real app, we would cache this to avoid repeated API calls
                if 'impact_simulation' not in st.session_state:
                    try:
                        st.session_state.impact_simulation = st.session_state.ai_agent.simulate_earthquake_impact(
                            location,
                            eq['magnitude'],
                            eq['depth_km']
                        )
                    except Exception as e:
                        st.error(f"Error generating impact simulation: {e}")
                        st.session_state.impact_simulation = {"error": str(e)}

            sim = st.session_state.impact_simulation
            if 'error' in sim:
                st.error(sim['error'])
            elif 'raw_simulation' in sim:
                st.markdown(sim['raw_simulation'])
            elif 'choices' in sim:
                st.markdown(str(sim['choices']))
            else:
                # Display structured impact simulation (Blueverse Foundry/GPT-4o mini)
                for section, value in sim.items():
                    st.markdown(f"### {section.replace('_', ' ').title()}")
                    if isinstance(value, list):
                        for item in value:
                            st.markdown(f"- {item}")
                    else:
                        st.markdown(str(value))
        
        with ai_tab3:
            st.subheader("Emergency Response Plan")
            
            if 'impact_simulation' not in st.session_state:
                st.info("Please view the Impact Simulation tab first to generate a response plan.")
            else:
                with st.spinner("Generating emergency response plan with AI..."):
                    # In a real app, we would cache this to avoid repeated API calls
                    if 'response_plan' not in st.session_state:
                        try:
                            earthquake_data = {
                                'location': location,
                                'magnitude': eq['magnitude'],
                                'depth_km': eq['depth_km']
                            }
                            st.session_state.response_plan = st.session_state.ai_agent.generate_response_plan(
                                earthquake_data,
                                st.session_state.impact_simulation
                            )
                        except Exception as e:
                            st.error(f"Error generating response plan: {e}")
                            st.session_state.response_plan = {"error": str(e)}
                
                rp = st.session_state.response_plan
                if 'error' in rp:
                    st.error(rp['error'])
                elif 'raw_plan' in rp:
                    st.markdown(rp['raw_plan'])
                elif 'choices' in rp:
                    st.markdown(str(rp['choices']))
                else:
                    # Display structured response plan (Blueverse Foundry/GPT-4o mini)
                    for section, value in rp.items():
                        st.markdown(f"### {section.replace('_', ' ').title()}")
                        if isinstance(value, list):
                            for item in value:
                                st.markdown(f"- {item}")
                        else:
                            st.markdown(str(value))

# Footer
st.markdown("---")
st.markdown("© 2023 Earthquake Disaster Management System | Powered by Agentic AI")

# Add custom CSS
st.markdown("""
<style>
.stApp {
    background-color: #f5f5f5;
}
.stTabs [data-baseweb="tab-list"] {
    gap: 24px;
}
.stTabs [data-baseweb="tab"] {
    height: 50px;
    white-space: pre-wrap;
    background-color: #f0f2f6;
    border-radius: 4px 4px 0px 0px;
    gap: 1px;
    padding-top: 10px;
    padding-bottom: 10px;
}
.stTabs [aria-selected="true"] {
    background-color: #ffffff;
    border-bottom: 2px solid #4e89ae;
}
</style>
""", unsafe_allow_html=True)