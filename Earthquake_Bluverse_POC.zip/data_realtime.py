import requests
from typing import List, Dict, Any, Optional

BASE_URL = "https://earthquake-bv.vercel.app/api/earthquakes"


def fetch_past_hour() -> List[Dict[str, Any]]:
    """Fetch all earthquakes from the past hour."""
    url = f"{BASE_URL}/past-hour"
    response = requests.get(url, headers={"Accept": "application/json"})
    response.raise_for_status()
    return response.json()


def fetch_past_day_m25() -> List[Dict[str, Any]]:
    """Fetch M2.5+ earthquakes from the past day."""
    url = f"{BASE_URL}/past-day/m2.5"
    response = requests.get(url, headers={"Accept": "application/json"})
    response.raise_for_status()
    return response.json()


def fetch_latest_10() -> List[Dict[str, Any]]:
    """Fetch the latest 10 earthquakes."""
    url = f"{BASE_URL}/latest-10"
    response = requests.get(url, headers={"Accept": "application/json"})
    response.raise_for_status()
    return response.json()


def fetch_custom(starttime: str, endtime: str, minmagnitude: Optional[float] = None) -> List[Dict[str, Any]]:
    """Fetch earthquakes by custom query (start time, end time, min magnitude). Dates in YYYY-MM-DD format."""
    params = {
        "starttime": starttime,
        "endtime": endtime
    }
    if minmagnitude is not None:
        params["minmagnitude"] = minmagnitude
    url = f"{BASE_URL}/custom"
    response = requests.get(url, params=params, headers={"Accept": "application/json"})
    response.raise_for_status()
    return response.json()


if __name__ == "__main__":
    # Validate all functions
    print("Past hour earthquakes:")
    print(fetch_past_hour())
    print("\nPast day M2.5+ earthquakes:")
    print(fetch_past_day_m25())
    print("\nLatest 10 earthquakes:")
    print(fetch_latest_10())
    print("\nCustom query (2025-08-01 to 2025-08-27, min magnitude 4):")
    print(fetch_custom("2025-08-01", "2025-08-27", 4))
