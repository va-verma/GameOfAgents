from langchain_core.tools import tool
import requests
from typing import Optional

BASE_URL = "https://earthquake-bv.vercel.app/api/earthquakes"

@tool
def get_earthquakes_past_hour():
    """
    Fetches all earthquakes from the past hour.
    :return: List of earthquake data dictionaries.
    """
    try:
        url = f"{BASE_URL}/past-hour"
        response = requests.get(url, headers={"Accept": "application/json"})
        response.raise_for_status()
        return response.json()
    except Exception as e:
        return {"error": str(e)}

@tool
def get_earthquakes_past_day_m25():
    """
    Fetches M2.5+ earthquakes from the past day.
    :return: List of earthquake data dictionaries.
    """
    try:
        url = f"{BASE_URL}/past-day/m2.5"
        response = requests.get(url, headers={"Accept": "application/json"})
        response.raise_for_status()
        return response.json()
    except Exception as e:
        return {"error": str(e)}

@tool
def get_latest_10_earthquakes():
    """
    Fetches the latest 10 earthquakes.
    :return: List of earthquake data dictionaries.
    """
    try:
        url = f"{BASE_URL}/latest-10"
        response = requests.get(url, headers={"Accept": "application/json"})
        response.raise_for_status()
        return response.json()
    except Exception as e:
        return {"error": str(e)}

@tool
def get_custom_earthquakes(starttime: str, endtime: str, minmagnitude: Optional[float] = None):
    """
    Fetches earthquakes based on custom query parameters.
    :param starttime: Start date in YYYY-MM-DD format.
    :param endtime: End date in YYYY-MM-DD format.
    :param minmagnitude: Optional minimum magnitude filter.
    :return: List of earthquake data dictionaries.
    """
    try:
        params = {
            "starttime": starttime,
            "endtime": endtime
        }
        if minmagnitude is not None:
            params["minmagnitude"] = minmagnitude

        url = f"{BASE_URL}/custom"
        response = requests.get(url, params=params, headers={"Accept": "application/json"})
        response.raise_for_status()
        return response.json()
    except Exception as e:
        return {"error": str(e)}

if __name__ == "__main__":
    result = get_earthquakes_past_hour.invoke({})
    print(result)