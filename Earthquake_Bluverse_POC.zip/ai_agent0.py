import os
import json
import requests
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class EarthquakeAIAgent:
    """
    Agent class for earthquake analysis and prediction using TogetherAI API
    """
    def __init__(self):
        self.api_key = os.getenv("TOGETHER_API_KEY")
        self.api_url = "https://api.together.xyz/v1/chat/completions"
        self.model = "meta-llama/Llama-3.3-70B-Instruct-Turbo-Free"
        
        if not self.api_key:
            raise ValueError("TogetherAI API key not found. Please check your .env file.")
    
    def _call_api(self, messages):
        """
        Make a call to the TogetherAI API
        """
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": self.model,
            "messages": messages,
            "stream": False,  # We don't want streaming for this application
            "temperature": 0.7,
            "max_tokens": 1000
        }
        
        try:
            response = requests.post(self.api_url, headers=headers, json=data)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"API call failed: {e}")
            return None
    
    def analyze_earthquake_risk(self, location, historical_data=None):
        """
        Analyze earthquake risk for a specific location
        """
        prompt = f"""You are an expert seismologist and disaster management specialist. 
        Analyze the earthquake risk for {location} based on geological factors, historical seismic activity, and infrastructure resilience.
        
        Provide a detailed risk assessment including:
        1. Geological vulnerability factors
        2. Historical earthquake patterns
        3. Potential magnitude range
        4. Infrastructure vulnerability
        5. Recommended preparedness measures
        
        Format your response as a JSON object with these sections.
        """
        
        messages = [
            {"role": "system", "content": "You are an AI assistant specializing in earthquake analysis and disaster management."},
            {"role": "user", "content": prompt}
        ]
        
        response = self._call_api(messages)
        if response and 'choices' in response:
            try:
                # Try to parse as JSON
                content = response['choices'][0]['message']['content']
                print(content)
                return json.loads(content)
            except json.JSONDecodeError:
                # If not valid JSON, return the raw text
                return {"raw_analysis": response['choices'][0]['message']['content']}
        
        return {"error": "Failed to get analysis from AI"}
    
    def simulate_earthquake_impact(self, location, magnitude, depth, population_density=None, infrastructure_data=None):
        """
        Simulate the impact of an earthquake with given parameters
        """
        prompt = f"""You are an expert in earthquake simulation and impact assessment.
        
        Simulate the impact of an earthquake with the following parameters:
        - Location: {location}
        - Magnitude: {magnitude}
        - Depth: {depth} km
        
        Provide a detailed impact assessment including:
        1. Expected ground shaking intensity (MMI scale)
        2. Potential for liquefaction and landslides
        3. Estimated infrastructure damage (buildings, roads, utilities)
        4. Potential casualties and displacement
        5. Secondary hazards (fires, tsunamis if coastal)
        6. Critical response needs
        
        Format your response as a JSON object with these sections.
        """
        
        messages = [
            {"role": "system", "content": "You are an AI assistant specializing in earthquake simulation and impact assessment."},
            {"role": "user", "content": prompt}
        ]
        
        response = self._call_api(messages)
        if response and 'choices' in response:
            try:
                # Try to parse as JSON
                content = response['choices'][0]['message']['content']
                return json.loads(content)
            except json.JSONDecodeError:
                # If not valid JSON, return the raw text
                return {"raw_simulation": response['choices'][0]['message']['content']}
        
        return {"error": "Failed to get simulation from AI"}
    
    def generate_response_plan(self, earthquake_data, impact_assessment, available_resources=None):
        """
        Generate an emergency response plan based on earthquake data and impact assessment
        """
        # Format the earthquake data and impact assessment for the prompt
        eq_info = f"Location: {earthquake_data.get('location', 'Unknown')}, Magnitude: {earthquake_data.get('magnitude', 'Unknown')}, Depth: {earthquake_data.get('depth_km', 'Unknown')} km"
        
        prompt = f"""You are an expert in emergency management and disaster response.
        
        Generate a comprehensive emergency response plan for the following earthquake scenario:
        
        {eq_info}
        
        Impact Assessment Summary:
        {impact_assessment.get('raw_simulation', json.dumps(impact_assessment, indent=2))}
        
        Provide a detailed response plan including:
        1. Immediate actions (first 24 hours)
        2. Resource allocation priorities
        3. Evacuation zones and routes
        4. Shelter establishment locations
        5. Medical response coordination
        6. Infrastructure restoration priorities
        7. Communication strategy
        
        Format your response as a JSON object with these sections.
        """
        
        messages = [
            {"role": "system", "content": "You are an AI assistant specializing in emergency management and disaster response."},
            {"role": "user", "content": prompt}
        ]
        
        response = self._call_api(messages)
        if response and 'choices' in response:
            try:
                # Try to parse as JSON
                content = response['choices'][0]['message']['content']
                return json.loads(content)
            except json.JSONDecodeError:
                # If not valid JSON, return the raw text
                return {"raw_plan": response['choices'][0]['message']['content']}
        
        return {"error": "Failed to generate response plan from AI"}
    
    def get_preparedness_recommendations(self, location, risk_level="medium"):
        """
        Get preparedness recommendations for a location based on risk level
        """
        prompt = f"""You are an expert in earthquake preparedness and disaster risk reduction.
        
        Provide comprehensive earthquake preparedness recommendations for {location} with a {risk_level} risk level.
        
        Include recommendations for:
        1. Individual/family preparedness
        2. Community preparedness
        3. Infrastructure resilience measures
        4. Early warning systems
        5. Education and awareness programs
        6. Policy recommendations
        
        Format your response as a JSON object with these sections.
        """
        
        messages = [
            {"role": "system", "content": "You are an AI assistant specializing in earthquake preparedness and disaster risk reduction."},
            {"role": "user", "content": prompt}
        ]
        
        response = self._call_api(messages)
        if response and 'choices' in response:
            try:
                # Try to parse as JSON
                content = response['choices'][0]['message']['content']
                return json.loads(content)
            except json.JSONDecodeError:
                # If not valid JSON, return the raw text
                return {"raw_recommendations": response['choices'][0]['message']['content']}
        
        return {"error": "Failed to get recommendations from AI"}