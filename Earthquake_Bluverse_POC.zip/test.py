import os
import json
import requests
from dotenv import load_dotenv


url = "https://blueverse-foundry.ltimindtree.com/chatservice/chat"
headers = {
    "Content-Type": "application/json",
    "Authorization": "Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJmdVdXcndULWRia28xZ2JwbmFFWkU2V2d1RjJ4RERGSHAyMlYzdUV6UDA4In0.eyJleHAiOjE3NTY0MTA2MDUsImlhdCI6MTc1NjQwOTEwNSwiYXV0aF90aW1lIjoxNzU2NDA4Mzk0LCJqdGkiOiJvbnJ0cnQ6ZDYxNGE3ZjgtOTRkMS00ZDRmLWFiMDYtMTdhN2I5ZjAyYTdiIiwiaXNzIjoiaHR0cHM6Ly9ibHVldmVyc2UtZm91bmRyeS5sdGltaW5kdHJlZS5jb20va2V5Y2xvYWsvcmVhbG1zL2NhbnZhc2FpIiwiYXVkIjpbImJyb2tlciIsImFjY291bnQiXSwic3ViIjoiM2NkY2U1NTUtNTc2Yi00Njc2LTg2NGYtNmEzZGJhYmM3YTk2IiwidHlwIjoiQmVhcmVyIiwiYXpwIjoiY2FudmFzYWktY29udHJvbHBsYW5lLXVpIiwic2lkIjoiODY4YTBjZDUtNWVjMS00YTJlLTgzODQtNDRmY2JjY2VjZDc2IiwiYWNyIjoiMSIsImFsbG93ZWQtb3JpZ2lucyI6WyJodHRwczovL2JsdWV2ZXJzZS1mb3VuZHJ5Lmx0aW1pbmR0cmVlLmNvbS9zdHVkaW8iLCIqIl0sInJlYWxtX2FjY2VzcyI6eyJyb2xlcyI6WyJkZWZhdWx0LXJvbGVzLWNhbnZhc2FpIiwib2ZmbGluZV9hY2Nlc3MiLCJ1bWFfYXV0aG9yaXphdGlvbiJdfSwicmVzb3VyY2VfYWNjZXNzIjp7ImJyb2tlciI6eyJyb2xlcyI6WyJyZWFkLXRva2VuIl19LCJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX19LCJzY29wZSI6Im9wZW5pZCBlbWFpbCBHcm91cFNjb3BlIHByb2ZpbGUiLCJ1cG4iOiJhMjg4NjFmOS1iNDk0LTQ1ZGEtYjBiZS0wZDA3MTE1ODQyMDkiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwibmFtZSI6IlZhaWJoYXYgVmVybWEiLCJncm91cHMiOlsiZGVmYXVsdC1yb2xlcy1jYW52YXNhaSIsIm9mZmxpbmVfYWNjZXNzIiwidW1hX2F1dGhvcml6YXRpb24iXSwicHJlZmVycmVkX3VzZXJuYW1lIjoiYTI4ODYxZjktYjQ5NC00NWRhLWIwYmUtMGQwNzExNTg0MjA5IiwiZ2l2ZW5fbmFtZSI6IlZhaWJoYXYiLCJmYW1pbHlfbmFtZSI6IlZlcm1hIiwiZW1haWwiOiJ2YWliaGF2LnZlcm1hQGx0aW1pbmR0cmVlLmNvbSJ9.BkWfp4tAvvU-ey3YITWkoDSONNWFp0Zl3KSFOQNUkIISEDJHpVlWQzc-Jnod6Pc5KoEfsAvi2TLwJpmx9Qx9MOKtacN1P48DK_9C-GpqJIMHSXtfUXkXYGcPd6bN_X42GrI2LDG-CDNdQGEtwNtwDnQ_wjwKasew-cNx8tBde8qBr-igGLR-L7VZNalWWwfnDgZSkQP9pYBbj4g3Ccl7JoVv6psAggOZMA_QnXp-Rh1d5tgQrRxxuDNnGE9UXOQ1u--vlfvKL-BJfj6Y99E7Iu0OL47XaDznu_j0ACeiHK_2KIXv59h5WOt31OVgl70odbRml7KhKFBfj1PtQy88Ew"
}
payload = {
    # "query": "Latitude -30.239209778992034,Longitude -71.91047998674445",
    "query": "Check for a major earthquake in last 1 day",
    "space_name": "analyze_earthquake_risk_68bd6be3",
    "flowId": "68a9b9093c336dbd12b23225"
}


try:
    response = requests.post(url, headers=headers, json=payload)
    response.raise_for_status()
    data = response.json()
    # print("data:", data)

    # GPT-4o mini model response structure
    if 'response' in data:
        content = data['response']
        try:
            print(json.loads(content))
        except json.JSONDecodeError:
            print (f"raw_analysis: {content}")
    else:
        print("error: No output returned in response")

except Exception as e:
    print(f"error: {str(e)}")


