import os
import json
import requests
from dotenv import load_dotenv


url = "https://blueverse-foundry.ltimindtree.com/chatservice/chat"
headers = {
    "Content-Type": "application/json",
    "Authorization": "Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJmdVdXcndULWRia28xZ2JwbmFFWkU2V2d1RjJ4RERGSHAyMlYzdUV6UDA4In0.eyJleHAiOjE3NTYxMjAwMDUsImlhdCI6MTc1NjExODUwNSwiYXV0aF90aW1lIjoxNzU2MTE2OTk0LCJqdGkiOiJvbnJ0cnQ6N2ZjZjJiNjUtOTkyNi00YWY3LWJmMTItMGQyNDE1ZjI0ZWY0IiwiaXNzIjoiaHR0cHM6Ly9ibHVldmVyc2UtZm91bmRyeS5sdGltaW5kdHJlZS5jb20va2V5Y2xvYWsvcmVhbG1zL2NhbnZhc2FpIiwiYXVkIjpbImJyb2tlciIsImFjY291bnQiXSwic3ViIjoiM2NkY2U1NTUtNTc2Yi00Njc2LTg2NGYtNmEzZGJhYmM3YTk2IiwidHlwIjoiQmVhcmVyIiwiYXpwIjoiY2FudmFzYWktY29udHJvbHBsYW5lLXVpIiwic2lkIjoiYjZlOTNiNDAtNzc0OC00OWM5LThiMjktOGU0YjQ1ZGViOGYxIiwiYWNyIjoiMSIsImFsbG93ZWQtb3JpZ2lucyI6WyJodHRwczovL2JsdWV2ZXJzZS1mb3VuZHJ5Lmx0aW1pbmR0cmVlLmNvbS9zdHVkaW8iLCIqIl0sInJlYWxtX2FjY2VzcyI6eyJyb2xlcyI6WyJkZWZhdWx0LXJvbGVzLWNhbnZhc2FpIiwib2ZmbGluZV9hY2Nlc3MiLCJ1bWFfYXV0aG9yaXphdGlvbiJdfSwicmVzb3VyY2VfYWNjZXNzIjp7ImJyb2tlciI6eyJyb2xlcyI6WyJyZWFkLXRva2VuIl19LCJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX19LCJzY29wZSI6Im9wZW5pZCBlbWFpbCBHcm91cFNjb3BlIHByb2ZpbGUiLCJ1cG4iOiJhMjg4NjFmOS1iNDk0LTQ1ZGEtYjBiZS0wZDA3MTE1ODQyMDkiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwibmFtZSI6IlZhaWJoYXYgVmVybWEiLCJncm91cHMiOlsiZGVmYXVsdC1yb2xlcy1jYW52YXNhaSIsIm9mZmxpbmVfYWNjZXNzIiwidW1hX2F1dGhvcml6YXRpb24iXSwicHJlZmVycmVkX3VzZXJuYW1lIjoiYTI4ODYxZjktYjQ5NC00NWRhLWIwYmUtMGQwNzExNTg0MjA5IiwiZ2l2ZW5fbmFtZSI6IlZhaWJoYXYiLCJmYW1pbHlfbmFtZSI6IlZlcm1hIiwiZW1haWwiOiJ2YWliaGF2LnZlcm1hQGx0aW1pbmR0cmVlLmNvbSJ9.WgDWs3egcZlJ8OdUEqAWmMpop-zC62LBoONOqTUU9KEMIDOqalmvnOnitbkfbumxyqMZZP7evcdfgT7B9I1bQMhbO0wz78dXJS1J92071H9Omh-JgzUSLAf2hO-kjJXdOKuIrXSlRdblbBPigokwtB4-amlDCeBUXmUgaNKPht7HFpbteUM-4zaFqzPQmOBgFUag2V6BZ177O_YydJxDeuv70zlNy1ouCKkNuFZffycURSxHzTINtZZQMghE_-3p3jyu1n_6aXkbJkxQD8YTeB72LJ5VhVV7PTKHe3YCCfgKK94VJEjNlEAllnJKAisrbLoQ6zel3JwVJ1ZbQuL_NA"  # Replace 'Token' with your actual token
}
payload = {
    "query": "Latitude -30.239209778992034,Longitude -71.91047998674445",
    "space_name": "analyze_earthquake_risk_68bd6be3",
    "flowId": "68a9b9093c336dbd12b23225"
}


try:
    response = requests.post(url, headers=headers, json=payload)
    response.raise_for_status()
    data = response.json()
    # print("data:", data)

    # GPT-4o mini model response structure
    if 'response' in data:
        content = data['response']
        try:
            print(json.loads(content))
        except json.JSONDecodeError:
            print (f"raw_analysis: {content}")
    else:
        print("error: No output returned in response")

except Exception as e:
    print(f"error: {str(e)}")


